package classes

class TokenMatch {
    Class tokenClass
    TokenType tokenType
}