package cs480.grammar

enum ActionType {
    Shift,
    Goto,
    Reduce,
    Accept
}