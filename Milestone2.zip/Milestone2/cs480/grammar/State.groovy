package cs480.grammar

class State {
    String id
    Map<String, Action> actions

    Action getAction(Expression curExpr, Expression lookahead) {
        
    }
}