package classes

import classes.Token

class OpToken extends Token {

}